<script setup>
</script>

<template>
  <q-page padding>
    <h1>Index page</h1>
  </q-page>
</template>